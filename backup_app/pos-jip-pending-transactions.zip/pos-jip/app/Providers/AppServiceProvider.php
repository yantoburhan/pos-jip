<?php

namespace App\Providers;

use App\Models\User;
use App\Policies\UserPolicy;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        User::class => UserPolicy::class, // <-- TAMBAHKAN BARIS INI
        Product::class => ProductPolicy::class,
        Level::class => LevelPolicy::class,
        Customer::class => CustomerPolicy::class,
        Role::class => RolePolicy::class,
        Transaction::class => TransactionPolicy::class,
    ];
}
