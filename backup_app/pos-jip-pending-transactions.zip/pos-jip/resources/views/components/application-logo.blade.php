<img {{ $attributes }} src="{{ asset('images/logo-jip.png') }}" alt="Logo Aplikasi">
