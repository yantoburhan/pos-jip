<?php if(session('success')): ?>
    <div class="mb-4 rounded-md bg-green-100 p-4 text-sm font-medium text-green-800" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="mb-4 rounded-md bg-red-100 p-4 text-sm font-medium text-red-800" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('info')): ?>
    <div class="mb-4 rounded-md bg-blue-100 p-4 text-sm font-medium text-blue-800" role="alert">
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>
<?php /**PATH F:\carrik\laravel\pos-jip\resources\views/components/message.blade.php ENDPATH**/ ?>