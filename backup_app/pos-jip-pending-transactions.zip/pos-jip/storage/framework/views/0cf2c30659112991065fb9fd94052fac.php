<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Buat Level Baru')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-slate-800 overflow-hidden shadow-lg sm:rounded-xl">
                <form method="POST" action="<?php echo e(route('levels.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="p-6 sm:p-8">

                        <?php if($errors->any()): ?>
                            <div class="mb-6 p-4 bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400 rounded-lg">
                                <p class="font-bold">Oops! Ada beberapa kesalahan:</p>
                                <ul class="list-disc list-inside mt-2 text-sm">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        
                        <div id="level-rows-container" class="space-y-6">
                            
                            <div class="level-row grid grid-cols-12 gap-4 items-end">
                                
                                <div class="col-span-12 sm:col-span-5">
                                    <label for="levels[0][name]" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Nama Level</label>
                                    <input id="levels[0][name]" class="block mt-1 w-full bg-gray-50 dark:bg-slate-900/50 border-gray-300 dark:border-slate-600 focus:border-indigo-500 dark:focus:border-indigo-500 focus:ring-indigo-500 dark:focus:ring-indigo-500 rounded-md shadow-sm text-gray-900 dark:text-gray-200" 
                                           type="text" name="levels[0][name]" required />
                                </div>

                                
                                <div class="col-span-12 sm:col-span-5">
                                    <label for="levels[0][level_point]" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Minimal Point</label>
                                    <input id="levels[0][level_point]" min="0" class="block mt-1 w-full bg-gray-50 dark:bg-slate-900/50 border-gray-300 dark:border-slate-600 focus:border-indigo-500 dark:focus:border-indigo-500 focus:ring-indigo-500 dark:focus:ring-indigo-500 rounded-md shadow-sm text-gray-900 dark:text-gray-200" 
                                           type="number" name="levels[0][level_point]" required />
                                </div>
                                
                                
                                <div class="col-span-12 sm:col-span-2"></div>
                            </div>
                        </div>

                        
                        <div class="mt-6">
                            <button type="button" id="add-level-row" class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-800">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                Tambah Level
                            </button>
                        </div>
                    </div>

                    
                    <div class="flex items-center justify-end px-6 py-4 bg-gray-50 dark:bg-slate-800/50 border-t dark:border-slate-700">
                        <a href="<?php echo e(route('levels.index')); ?>" class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 dark:focus:ring-offset-slate-800 transition ease-in-out duration-150 mr-4">
                            Batal
                        </a>
                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 active:bg-green-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-slate-800 transition ease-in-out duration-150">
                            Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const container = document.getElementById('level-rows-container');
            const addRowButton = document.getElementById('add-level-row');
            let rowIndex = 1; // Mulai dari 1 karena baris ke-0 sudah ada

            addRowButton.addEventListener('click', () => {
                const newRow = document.createElement('div');
                newRow.classList.add('level-row', 'grid', 'grid-cols-12', 'gap-4', 'items-end');

                newRow.innerHTML = `
                    <div class="col-span-12 sm:col-span-5">
                        <label for="levels[${rowIndex}][name]" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Nama Level</label>
                        <input id="levels[${rowIndex}][name]" class="block mt-1 w-full bg-gray-50 dark:bg-slate-900/50 border-gray-300 dark:border-slate-600 focus:border-indigo-500 dark:focus:border-indigo-500 focus:ring-indigo-500 dark:focus:ring-indigo-500 rounded-md shadow-sm text-gray-900 dark:text-gray-200" 
                               type="text" name="levels[${rowIndex}][name]" required />
                    </div>

                    <div class="col-span-12 sm:col-span-5">
                        <label for="levels[${rowIndex}][level_point]" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Minimal Point</label>
                        <input id="levels[${rowIndex}][level_point]" min="0" class="block mt-1 w-full bg-gray-50 dark:bg-slate-900/50 border-gray-300 dark:border-slate-600 focus:border-indigo-500 dark:focus:border-indigo-500 focus:ring-indigo-500 dark:focus:ring-indigo-500 rounded-md shadow-sm text-gray-900 dark:text-gray-200" 
                               type="number" name="levels[${rowIndex}][level_point]" required />
                    </div>
                    
                    <div class="col-span-12 sm:col-span-2">
                        <button type="button" class="remove-level-row inline-flex items-center justify-center w-full px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-800">
                            Hapus
                        </button>
                    </div>
                `;

                container.appendChild(newRow);
                rowIndex++;
            });

            // Event listener untuk tombol hapus
            container.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('remove-level-row')) {
                    e.target.closest('.level-row').remove();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\carrik\laravel\pos-jip\resources\views/levels/create.blade.php ENDPATH**/ ?>