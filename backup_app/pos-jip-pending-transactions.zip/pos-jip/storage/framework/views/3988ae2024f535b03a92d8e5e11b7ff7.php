

<?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors duration-150">
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-200"><?php echo e($customer->no_hp_cust); ?></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white"><?php echo e($customer->cust_name); ?></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-200"><?php echo e($customer->level->name ?? 'N/A'); ?></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-200 text-right"><?php echo e(number_format($customer->cust_point, 0, ',', '.')); ?></td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-200 text-right">Rp <?php echo e(number_format($customer->total_spent, 0, ',', '.')); ?></td>
        <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
            <div class="flex items-center justify-center space-x-2">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $customer)): ?>
                    <a href="<?php echo e(route('customers.edit', $customer->no_hp_cust)); ?>" class="inline-block px-3 py-1.5 bg-yellow-500 text-white rounded-md text-xs font-semibold hover:bg-yellow-600 transition-all">Ubah</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $customer)): ?>
                    <form action="<?php echo e(route('customers.destroy', $customer->no_hp_cust)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Yakin ingin menghapus customer ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="px-3 py-1.5 bg-red-600 text-white rounded-md text-xs font-semibold hover:bg-red-700 transition-all">Hapus</button>
                    </form>
                <?php endif; ?>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6" class="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
            <?php if(request('q')): ?>
                Customer dengan nama atau no. hp "<?php echo e(request('q')); ?>" tidak ditemukan.
            <?php else: ?>
                Tidak ada data customer.
            <?php endif; ?>
        </td>
    </tr>
<?php endif; ?><?php /**PATH F:\carrik\laravel\pos-jip\resources\views/customers/partials/customer-rows.blade.php ENDPATH**/ ?>