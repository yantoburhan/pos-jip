<?php

return [
    1 => 'Admin',
    2 => 'Kasir',
    // nanti bisa ditambah lagi misalnya 3 => 'Supervisor'
];
